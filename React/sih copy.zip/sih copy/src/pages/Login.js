import React from "react";
import Loader from "../components/Loader";

class Login extends React.Component {
  state = { num: 0, loading: true };

  componentDidMount() {
    // call api here
    setInterval(() => {
      this.setState({ num: this.state.num + 1, loading: false });
    }, 2500);
  }

  render() {
    if (this.state.loading) {
      return <Loader />;
    } else {
      return (
        <div>
          <h1>{this.state.num}</h1>
          <h1>This is a login.</h1>
          <h1>This is a login.</h1>
          <h1>This is a login.</h1>
          <h1>This is a login.</h1>
          <h1>This is a login.</h1>
          <h1>This is a login.</h1>
          <h1>This is a login.</h1>
        </div>
      );
    }
  }
}

export default Login;
