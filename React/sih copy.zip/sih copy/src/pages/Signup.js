import React from "react";
const Signup = () => {
  return (
    <div>
      <h1>This is a Signup.</h1>
      <h1>This is a Signup.</h1>
      <h1>This is a Signup.</h1>
      <h1>This is a Signup.</h1>
      <h1>This is a Signup.</h1>
      <h1>This is a Signup.</h1>
      <h1>This is a Signup.</h1>
      <h1>This is a Signup.</h1>
    </div>
  );
};

export default Signup;
