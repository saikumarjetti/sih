import React from "react";
import { Link } from "react-router-dom";
// import Login from "./Login";
// import Signup from "./Signup";
const Home = () => {
  return (
    <div>
      <h1>This is a home.</h1>
      <div>
        <nav>
          <Link to="/login">login</Link>
          <Link to="/lignup">Signup</Link>
        </nav>
      </div>
    </div>
  );
};

export default Home;
