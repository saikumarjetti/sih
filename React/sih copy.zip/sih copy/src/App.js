import "./App.css";
import { Link } from "react-router-dom";
function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>this is a App.js file</h1>
      </header>
      <br />
      <h2> this is app.js file </h2>
      <p>fweffwe fwe fw ef we fw ef ef</p>
      <p>fweffwe fwe fw ef we fw ef ef</p>
      <p>fweffwe fwe fw ef we fw ef ef</p>
      <p>fweffwe fwe fw ef we fw ef ef</p>
      <p>fweffwe fwe fw ef we fw ef ef</p>
      <p>fweffwe fwe fw ef we fw ef ef</p>
      <br />
      <br />
      <div>
        <Link to="/login">Login </Link>
        <br />
        <br />
        <br />
        <Link to="/signup">signup </Link>
      </div>
      <h4>Sstill in app.js file</h4>
    </div>
  );
}

export default App;
