import React from "react";

const Loader = (props) => {
  return (
    <div className="ui segment ">
      <div className="ui active transition visible dimmer">
        <div className="content">
          <div className="ui loader Loader"></div>
        </div>
      </div>
    </div>
  );
};

export default Loader;
